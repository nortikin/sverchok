# import libraries here
#


def sv_main():

    # in boilerplate - make your own sockets
    # 's','v','m' - data, vertices and matrices sockets, i.e.
    # 's', 'edges',edgs,
    # it is data socket (green point), 
    # def sv_main(edgs=[]):
    # in this case

    in_sockets = [
    ]

    # your code and definitions here
    #
    #
    #

    # out boilerplate - set your own sockets packet
    # the same principle as in in_sockets

    out_sockets = [
    ]

    return in_sockets, out_sockets
